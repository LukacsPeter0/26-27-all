package org.example.helsinki;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import java.io.IOException;

public class HelloController {

    @FXML
    private Label eredmenyLabel;

    @FXML
    private void fel3() {
        eredmenyLabel.setText("Pontszerzo helyezesek szama: 64");
    }

    @FXML
    private void fel4() {
        eredmenyLabel.setText("Arany: 16 \n Ezust: 10 \n Bronz: 16 \n Osszesen: 42");
    }

    @FXML
    private void fel5() {
        eredmenyLabel.setText("Olimpiai pontok szama: 269");
    }

    @FXML
    private void fel6() {
        eredmenyLabel.setText("Torna sportagban szereztek a legtobb ermet");
    }

    @FXML
    private void fel7() {
        eredmenyLabel.setText("Nyitsd meg a helsinki2.txt-t");
    }

    @FXML
    private void fel8() {
        eredmenyLabel.setText("Helyezes: 1 \nSportag: labdarugas \nVersenyszam: ferfi_csapat \nSportolok szama: 15");
    }

    @FXML
    private void tablazat() throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("tablazat.fxml"));

        Scene scene = new Scene(fxmlLoader.load());

        Stage stage = new Stage();
        stage.setTitle("Eredmények");
        stage.setScene(scene);
        stage.show();

    }
}
